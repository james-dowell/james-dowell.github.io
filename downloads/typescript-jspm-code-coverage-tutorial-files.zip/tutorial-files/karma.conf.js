'use strict';

var istanbul = require('istanbul');

module.exports = function (config) {
    var configuration = {
        autoWatch: false,
        frameworks: ['jspm', 'mocha', 'chai-sinon', 'chai'],
        reporters: ['dots', 'coverage'],
        logLevel: config.LOG_ERROR,
        plugins: [
            'karma-jspm',
            'karma-mocha',
            'karma-chai',
            'karma-chai-sinon',
            'karma-chrome-launcher',
            'karma-ng-html2js-preprocessor',
            'karma-coverage'
        ],
        browserNoActivityTimeout: 90000,


        basePath: './',

        browsers: [
            'ChromeSmall'
        ],

        customLaunchers: {
            ChromeSmall: {
                base: 'Chrome',
                flags: [
                    '--window-size=300,300',
                    '--window-position=-300,0',
                    '--incognito'
                ]
            }
        },

        preprocessors: {
            'src/**/*.html': ['ng-html2js'],
            '.tmp/scripts/**/!(*spec).js': ['coverage']
        },

        coverageReporter: {
            includeAllSources: true,
            instrumenters: { istanbul: istanbul },
            instrumenter: {
                '**/*.js': 'istanbul'
            },
            instrumenterOptions: {
                istanbul: {
                    includeUntested: true
                }
            },
            reporters: [
                // We'll create a remapped (to typescript) html report from this json report - James
                {
                    type: 'json',
                    dir: './.tmp/coverage-reports',
                    subdir: '.'
                },
            ]
        },

        proxies: {
            '/.tmp': '/base/.tmp'
        },

        jspm: {
            loadFiles: [
                '.tmp/scripts/**/*.spec.js'
            ],
            meta: {
                '.tmp/scripts/*': {
                    format: 'register'
                }
            },
            serveFiles: [
                '.tmp/scripts/**/*!(*.spec).js',
                'src/**/*.ts'
            ]
        }

    };

    config.set(configuration);
};
