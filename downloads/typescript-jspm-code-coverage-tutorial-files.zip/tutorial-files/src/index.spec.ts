
const expect: Chai.ExpectStatic = chai.expect;

import App from './index';

describe('test', () => {

    it('should return true from the tested function', () => {
        let app: App = new App;
        expect(app.testedFunction()).to.be.true;
    });

});
