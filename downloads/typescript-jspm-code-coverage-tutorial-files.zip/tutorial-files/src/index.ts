export var app = true;

export default class App {

    constructor() {}

    public testedFunction(): boolean {
        return true;
    }

    public untestedFunction(): boolean {
        return false;
    }

}
