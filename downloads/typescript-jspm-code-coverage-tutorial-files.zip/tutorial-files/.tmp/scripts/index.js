System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var app, App;
    return {
        setters:[],
        execute: function() {
            exports_1("app", app = true);
            App = (function () {
                function App() {
                }
                App.prototype.testedFunction = function () {
                    return true;
                };
                App.prototype.untestedFunction = function () {
                    return false;
                };
                return App;
            }());
            exports_1("default", App);
        }
    }
});
//# sourceMappingURL=index.js.map