System.register(['./index'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var index_1;
    var expect;
    return {
        setters:[
            function (index_1_1) {
                index_1 = index_1_1;
            }],
        execute: function() {
            expect = chai.expect;
            describe('test', function () {
                it('should return true from the tested function', function () {
                    var app = new index_1.default;
                    expect(app.testedFunction()).to.be.true;
                });
            });
        }
    }
});
//# sourceMappingURL=index.spec.js.map